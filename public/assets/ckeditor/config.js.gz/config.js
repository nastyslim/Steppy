(function() {
  CKEDITOR.config.toolbar = [['Image', 'HorizontalRule', 'Smiley', 'SpecialChar'], ['Bold', 'Italic', 'Underline', 'Strike', '-', 'Subscript', 'Superscript'], ['NumberedList', 'BulletedList', '-', 'Blockquote'], ['Link', 'Unlink', 'Anchor', 'LinkToNode', 'LinkToMenu'], ['Format', 'Font', 'FontSize'], ['TextColor', 'BGColor'], ['Maximize']];

}).call(this);
